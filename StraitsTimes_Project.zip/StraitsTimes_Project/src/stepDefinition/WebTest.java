package stepDefinition;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class WebTest {

	WebDriver driver;

	@Given("^Open Firefox and start application$")
	public void Open_Firefox_and_start_application() throws Throwable {

		driver = new FirefoxDriver();
		driver.manage().window().maximize();
		driver.get("http://www.straitstimes.com");
		
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		
		//driver.switchTo().frame("ebAd1074618079_expand_iframe_1074618079_9170749829161963");
		//driver.findElement(By.xpath(".//*[@id='close-button']")).click();
		//driver.switchTo().defaultContent();
	}
	
	@When("^I click LOGIN link$")
	public void I_click_LOGIN_link() throws Throwable {
		
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		driver.findElement(By.linkText("Login")).click();
	}

	@When("^I enter valid username and password$")
	public void I_enter_valid_username_and_password() throws Throwable {
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.id("j_username")).sendKeys("bianca_qatest@yopmail.com");
		driver.findElement(By.id("j_password")).sendKeys("Mouse123");
	}

	@Then("^I should be able to login successfully$")
	public void I_should_be_able_to_login_successfully() throws Throwable {
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.className("btn")).click();

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		if (driver.findElement(By.name("login-user-name")).isDisplayed()) {
			System.out.println("User has been login successfully.");
		} else {
			System.out.println("User Unable to Login!");
			driver.quit();
		}

	}

	@Given("^Main Article has a picture or video$")
	public void Main_Article_has_a_picture_or_video() throws Throwable {

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		if (driver
				.findElement(By
						.xpath("//*[@id='block-system-main']/div/div/div/div/div[2]/div/div/div/div[5]/div/div/div/div/a"))
				.isDisplayed()) {
			System.out.println("Main Article has a picture or video");
		} else {
			System.out.println("NO picture or video in the Main Article!");
			driver.quit();

		}
	}

	@When("^I click Main Article$")
	public void I_click_Main_Article() throws Throwable {
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(
				By.xpath("//*[@id='block-system-main']/div/div/div/div/div[2]/div/div/div/div[5]/div/div/div/div/a"))
				.click();
	}

	@Then("^page should be navigated to Main Article page$")
	public void page_should_be_navigated_to_Main_Article_page() throws Throwable {
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		if (driver.findElement(By.id("block-system-main")).isDisplayed()) {
			System.out.println("Page is navigated to Main Article");
		} else {
			System.out.println("Unable to Navigate to the Main Article Page!");
			driver.quit();
		}
	}

	@Then("^Picture or video is present in the article$")
	public void Picture_or_video_is_present_in_the_article() throws Throwable {
		if (driver.findElement(By.xpath("//*[@id='block-system-main']/div/div[2]/div[1]/div[1]")).isDisplayed()) {
			System.out.println("Picture or Video is present in the article");
		} else {
			System.out.println("Picture or Video is NOT Present in the article!");
			driver.quit();
		}
	}
	
	@After
	public void tearDown() throws Exception {
	    driver.quit();
	}
}
