package com.zyllem.exam.careers;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;

import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;

public class NewTest {

	private static WebDriver driver;

	@BeforeClass
	public void beforeClass() {
		System.setProperty("webdriver.gecko.driver", "/geckodriver");
		driver = new FirefoxDriver();
	}

	@AfterClass
	public void afterClass() {
		driver.quit();
	}

	public void goToZyllem() throws InterruptedException {
		// Open Zyllem Website
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("https://www.zyllem.com");

		String title = driver.getTitle();
		Assert.assertEquals(title, "Zyllem | Digitize your logistics");
		System.out.println("PASSED: Zyllem website is accessible");

	}

	public void clickCareers() throws InterruptedException {
		goToZyllem();
		Thread.sleep(3000);
		// Click on the “Careers” link (bottom of the page)
		WebElement careerslink = driver.findElement(By.partialLinkText("Careers"));
		careerslink.click();

		driver.get("https://zyllem.bamboohr.com/jobs");
		Thread.sleep(3000);

		WebElement qaengineer = driver.findElement(By.partialLinkText("QA Engineer"));
		qaengineer.click();
		System.out.println("PASSED: User is navigated to Careers page");

	}

	public void checkTerms() throws InterruptedException {
		clickCareers();
		Thread.sleep(3000);
		// Check the following Terms are Present
		String term1 = "WebDriver";
		String term2 = "JMeter";
		String term3 = "start-up";
		String term4 = "automate";
		if (driver.getPageSource().contains(term1)) {
			System.out.println("Term - " + term1 + " is Present");
		} else {
			System.out.println("Term - " + term1 + " is NOT Present");
			driver.quit();
		}

		if (driver.getPageSource().contains(term2)) {
			System.out.println("Term - " + term2 + " is Present");
		} else {
			System.out.println("Term - " + term2 + " is NOT Present");
			driver.quit();
		}

		if (driver.getPageSource().contains(term3)) {
			System.out.println("Term - " + term3 + " is Present");
		} else {
			System.out.println("Term - " + term3 + " is NOT Present");
			driver.quit();
		}

		if (driver.getPageSource().contains(term4)) {
			System.out.println("Term - " + term4 + " is Present");
		} else {
			System.out.println("Term - " + term4 + " is NOT Present");
			driver.quit();
		}

	}

	@Test
	public void ApplyToSite() throws InterruptedException, IOException {
		checkTerms();
		Thread.sleep(3000);
		driver.findElement(By.xpath("/html/body/div[1]/div[4]/div/div/a")).click();
		Thread.sleep(3000);
		
		String fname = "Bianca";
		String lname = "Salunga";
		String email = "biancasalunga@gmail.com";
		String phone = "98822305";
		String address = "Blk 158C Rivervale Crescent, #13-673, Singapore, 543158";
		String city = "Singapore";
		String province = "Singapore";
		String zipcode = "543158";
		String desiredSalary = "3300";
		String question3 = "Linkedin";
		
		//Fill up Form		
		driver.findElement(By.name("applicant[firstName]")).clear();
		driver.findElement(By.name("applicant[firstName]")).sendKeys(fname);
		Thread.sleep(1000);
		driver.findElement(By.name("applicant[lastName]")).clear();
		driver.findElement(By.name("applicant[lastName]")).sendKeys(lname);
		Thread.sleep(1000);
		driver.findElement(By.name("applicant[email]")).clear();
		driver.findElement(By.name("applicant[email]")).sendKeys(email);
		Thread.sleep(1000);
		driver.findElement(By.name("applicant[phone]")).clear();
		driver.findElement(By.name("applicant[phone]")).sendKeys(phone);
		Thread.sleep(1000);
		driver.findElement(By.name("location[addressLine1]")).clear();
		driver.findElement(By.name("location[addressLine1]")).sendKeys(address);
		Thread.sleep(1000);
		driver.findElement(By.name("location[city]")).clear();
		driver.findElement(By.name("location[city]")).sendKeys(city);
		Thread.sleep(1000);
		driver.findElement(By.name("location[stateId]")).clear();
		driver.findElement(By.name("location[stateId]")).sendKeys(province);
		Thread.sleep(1000);
		driver.findElement(By.name("location[zipcode]")).clear();
		driver.findElement(By.name("location[zipcode]")).sendKeys(zipcode);
		
		driver.findElement(By.partialLinkText("Singapore"));
		
		Thread.sleep(1000);
		driver.findElement(By.name("positionApplicant[desiredSalary]")).clear();
		driver.findElement(By.name("positionApplicant[desiredSalary]")).sendKeys(desiredSalary);
		
		Thread.sleep(1000);
		driver.findElement(By.name("customQuestion[3]")).clear();
		driver.findElement(By.name("customQuestion[3]")).sendKeys(question3);
		
		Thread.sleep(1000);
		
		String filepath = "/Users/Desktop/BiancaSalunga_CV.pdf";
		WebElement chooseFile = driver.findElement(By.xpath("//a[@class='attach-link btn']"));
		chooseFile.click();
		Thread.sleep(2000);
		chooseFile.sendKeys(filepath);
		chooseFile.sendKeys(Keys.RETURN);
		Thread.sleep(5000); //User selects the file in the uploaded popup and click Open

		driver.findElement(By.xpath("//button[contains(.,'Submit Application')]")).click();
		WebElement thankYou = driver.findElement(By.className("thanks"));
		thankYou.getText();
		
		WebElement successMsg = driver.findElement(By.className("success"));
		successMsg.getText();
		Thread.sleep(2000);
	}
}
