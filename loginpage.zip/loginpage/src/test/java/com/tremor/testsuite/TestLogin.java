package com.tremor.testsuite;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class TestLogin {
	private WebDriver driver;

	@BeforeClass
	public void beforeClass() {
		System.setProperty("webdriver.gecko.driver", "C:\\geckodriver.exe");
		driver = new FirefoxDriver();
	}

	@AfterClass
	public void afterClass() {
		driver.quit();
	}

	@Test
	public void goToLogin() {
		// TC1: [Login] User is navigated to Login page
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("https://bianca-salunga.github.io/");

		// TC2:[Login] Logo and background image are available and displayed
		// properly
		Boolean iselementpresent = driver.findElements(By.id("logo")).size() != 0;
		if (iselementpresent == true) {
			System.out.println("Logo is displayed");
		} else {
			System.out.println("Logo is not displayed!");
		}

		// TC3: [Login] Header is displayed correctly
		String search_h1 = "QA Test Login Page";
		WebElement header1 = driver.findElement(By.tagName("h1"));
		String head1 = header1.getText();
		Assert.assertEquals(head1, search_h1, "QA Test Login Page not displayed!");
	}

	@Test
	public void verifyFieldsAndLoginValidation() {
		this.goToLogin();
		// TC4: [Login] Username, Password fields and Login button are displayed
		String search_loginBtn = "Login";
		WebElement loginbtn = driver.findElement(By.id("login"));
		String login = loginbtn.getAttribute("value");
		Assert.assertEquals(login, search_loginBtn, "Login button not displayed!");

		String search_userName = "Username";
		String uname = driver.findElement(By.id("username")).getAttribute("placeholder");
		Assert.assertEquals(uname, search_userName, "Username not displayed!");

		String search_pWord = "Password";
		String pword = driver.findElement(By.id("password")).getAttribute("placeholder");
		Assert.assertEquals(pword, search_pWord, "Password not displayed!");

		// TC5: [Login] Username and Password fields are required fields
		driver.findElement(By.id("username")).sendKeys("");
		loginbtn.click();
		String tooltipTxt1 = "Please fill in this field.";
		String tooltipTxt1ToVerify = driver.findElement(By.id("username")).getAttribute("title");
		Assert.assertEquals(tooltipTxt1ToVerify, tooltipTxt1, "No validation displayed!");

		// TC6: [Login] Password validation message appears when invalid input
		driver.findElement(By.id("username")).clear();
		driver.findElement(By.id("username")).sendKeys("qatest");
		driver.findElement(By.id("password")).clear();
		driver.findElement(By.id("password")).sendKeys("123");
		loginbtn.click();
		String tooltipTxt3 = "Password must contain at least 8 characters, including UPPER, lowercase and numbers";
		String tooltipTxt3ToVerify = driver.findElement(By.id("password")).getAttribute("title");
		Assert.assertEquals(tooltipTxt3ToVerify, tooltipTxt3, "No validation displayed!");

		// TC7: [Login] Able to login successfully when correct login
		driver.findElement(By.id("username")).clear();
		driver.findElement(By.id("password")).clear();
		driver.findElement(By.id("username")).sendKeys("qatest");
		driver.findElement(By.id("password")).sendKeys("Mouse@bc");
		loginbtn.submit();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

		String newPage = "CONTACT US\nRequest information, book a studio, or plan your event!\nname\nphone\nemail *\nenquiry";
		String newPageVerify = driver.findElement(By.id("contact_form")).getText();
		Assert.assertEquals(newPageVerify, newPage, "Unable to login and incorrect page!");
	}
}
